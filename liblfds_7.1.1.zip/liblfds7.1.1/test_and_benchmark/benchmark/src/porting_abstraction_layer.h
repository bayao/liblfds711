/***** defines *****/
#define BENCHMARK_MEMORY_TYPE_SMP   1
#define BENCHMARK_MEMORY_TYPE_NUMA  2


