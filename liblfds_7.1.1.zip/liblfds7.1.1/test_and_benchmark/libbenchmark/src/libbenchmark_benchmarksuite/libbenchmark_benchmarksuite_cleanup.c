/***** includes *****/
#include "libbenchmark_benchmarksuite_internal.h"





/****************************************************************************/
#pragma warning( disable : 4100 )

void libbenchmark_benchmarksuite_cleanup( struct libbenchmark_benchmarksuite_state *bss )
{
  LFDS711_PAL_ASSERT( bss != NULL );

  return;
}

#pragma warning( default : 4100 )

