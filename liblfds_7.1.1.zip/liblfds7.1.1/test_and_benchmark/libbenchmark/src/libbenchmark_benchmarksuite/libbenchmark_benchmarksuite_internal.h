/***** the library wide include file *****/
#include "../libbenchmark_internal.h"

/***** private prototypes *****/

