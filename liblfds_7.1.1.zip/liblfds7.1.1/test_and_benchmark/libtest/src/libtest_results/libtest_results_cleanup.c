/***** includes *****/
#include "libtest_results_internal.h"





/****************************************************************************/
#pragma warning( disable : 4100 )

void libtest_results_cleanup( struct libtest_results_state *rs )
{
  LFDS711_PAL_ASSERT( rs != NULL );

  return;
}

#pragma warning( default : 4100 )

