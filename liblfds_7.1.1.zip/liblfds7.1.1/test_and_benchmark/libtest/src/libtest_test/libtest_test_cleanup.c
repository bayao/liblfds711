/***** includes *****/
#include "libtest_test_internal.h"





/****************************************************************************/
#pragma warning( disable : 4100 )

void libtest_test_cleanup( struct libtest_test_state *ts )
{
  LFDS711_PAL_ASSERT( ts != NULL );

  // TRD : we do naaauuuutttthhiiiinnnn'

  return;
}

#pragma warning( default : 4100 )

