/***** includes *****/
#include "lfds711_misc_internal.h"





/****************************************************************************/
struct lfds711_misc_globals
  lfds711_misc_globals = 
  {
    { LFDS711_PRNG_SEED }
  };

